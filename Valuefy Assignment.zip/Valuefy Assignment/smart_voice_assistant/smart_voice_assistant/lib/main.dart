import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(VoiceAssistantApp());

class VoiceAssistantApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Voice Assistant',
      home: VoiceAssistantScreen(),
    );
  }
}

class VoiceAssistantScreen extends StatefulWidget {
  @override
  _VoiceAssistantScreenState createState() => _VoiceAssistantScreenState();
}

class _VoiceAssistantScreenState extends State<VoiceAssistantScreen> {
  late stt.SpeechToText _speech;
  bool _isListening = false;
  String _transcription = '';
  String _summary = '';
  bool _isProcessing = false;

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
  }

  Future<void> _startListening() async {
    bool available = await _speech.initialize(
      onStatus: (status) => print('Status: $status'),
      onError: (error) => print('Error: $error'),
    );

    if (available) {
      setState(() {
        _isListening = true;
        _transcription = '';
      });
      _speech.listen(
        onResult: (result) {
          setState(() {
            _transcription = result.recognizedWords;
          });
        },
      );
    } else {
      print('Speech recognition not available');
    }
  }

  void _stopListening() {
    _speech.stop();
    setState(() => _isListening = false);
  }

  Future<void> _processTranscription() async {
    setState(() {
      _isProcessing = true;
    });

    final response = await http.post(
      Uri.parse('https://api.openai.com/v1/chat/completions'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer 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',
      },
      body: jsonEncode({
        'model': 'gpt-3.5-turbo',
        'messages': [
          {
            'role': 'system',
            'content': 'Extract tasks, dates, and summary from a meeting transcription.'
          },
          {
            'role': 'user',
            'content': _transcription
          }
        ],
      }),
    );

    if (response.statusCode == 200) {
      final result = jsonDecode(response.body);
      setState(() {
        _summary = result['choices'][0]['message']['content'];
        _isProcessing = false;
      });
    } else {
      print('Failed to process transcription: ${response.body}');
      setState(() => _isProcessing = false);
    }
  }

  Future<void> _addCalendarEvent() async {
    String eventUrl =
        'https://www.google.com/calendar/render?action=TEMPLATE&text=Meeting&details=$_summary&dates=20250220T120000Z/20250220T130000Z';
    if (await canLaunchUrl(Uri.parse(eventUrl))) {
      await launchUrl(Uri.parse(eventUrl));
    } else {
      print('Could not launch calendar URL');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Smart Voice Assistant'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Transcription:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(_transcription),
            SizedBox(height: 20),
            if (_isProcessing) CircularProgressIndicator(),
            if (_summary.isNotEmpty) ...[
              Text(
                'Extracted Summary:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(_summary),
            ],
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: _isListening ? _stopListening : _startListening,
                  child: Text(_isListening ? 'Stop Listening' : 'Start Listening'),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _transcription.isNotEmpty && !_isProcessing
                      ? _processTranscription
                      : null,
                  child: Text('Process Notes'),
                ),
              ],
            ),
            ElevatedButton(
              onPressed: _summary.isNotEmpty ? _addCalendarEvent : null,
              child: Text('Add to Calendar'),
            ),
          ],
        ),
      ),
    );
  }
}
